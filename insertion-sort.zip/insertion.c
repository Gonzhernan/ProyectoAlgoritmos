#include<stdio.h>

void swap(int *e1,int *e2) 
{
  int tmp = *e1;
  *e1 = *e2;
  *e2 = tmp;
}

void insertion_sort(int s[], int n)
{
  int i,j;
  for (i=1; i<n; i++) {
    j=i;
    while ((j>0) && (s[j] < s[j-1])) {
      swap(&s[j],&s[j-1]);
      j = j-1;
    }
  }
}

void print_array(int vect[], int len) 
{
  int i;
  printf("Imprimiendo array de: %d\n", len);
  for(i = 0; i < len ; i++) {
    printf("idx: %d = %d \n", i,vect[i]);
  }
}

int main() 
{
  int vect[10] = {9,5,7,8,4,3,2,5,6,1};
  print_array(vect,10);
  insertion_sort(vect,10);
  print_array(vect,10);
  return 0;
}