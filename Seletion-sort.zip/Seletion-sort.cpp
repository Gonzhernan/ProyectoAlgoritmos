#include <iostream>
using namespace std;

void ordena(int a[5])
{
    for(int i=0;i<5;i++)
    {
        for (int j=i;j<5;j++)
        {
            if (a[i] > a[j])
            {
                int aux = a[j];
                a[j] = a[i];
                a[i] = aux;
            }
        }
    }
}

int main()
{
    int a[5];
    for (int i=0;i<5;i++)
    {
        cout << "Ingrese el " << i <<"� elemento" << endl;
        cin >> a[i];
        cout << "\n\n";
    }
    ordena(a);
    cout << "Lista ordenada" << endl;
    for(int i=0; i < 5; i++)
    {
        cout << a[i] << endl;
    }
    return 1;
}
